"use client";

import { useState } from "react";
import { MinimalListLayout } from "./layouts/MinimalListLayout";
import { TwoColumnGridLayout } from "./layouts/TwoColumnGridLayout";
import { CardFlowLayout } from "./layouts/CardFlowLayout";

type ViewMode = "minimal" | "grid" | "cards";

export function EducationSection() {
  const [viewMode, setViewMode] = useState<ViewMode>("minimal");

  return (
    <section
      id="education"
      className="relative w-full py-28 md:py-40 bg-[#080808] dark:bg-[#080808] light-mode:bg-[#F5F5F7] text-white dark:text-white light-mode:text-zinc-900 overflow-hidden transition-colors duration-400"
    >
      <div className="relative w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header & Mode Switcher */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-14 md:mb-20 gap-8 pb-8 border-b border-white/[0.08] light-mode:border-black/[0.08] antialiased">
          <div className="flex flex-col gap-2.5">
            <div className="flex items-center gap-3">
              <span className="font-mono text-xs text-zinc-400 light-mode:text-zinc-600 uppercase tracking-widest">
                04. Education
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#af5bf0]" />
              <span className="font-mono text-xs text-zinc-400 light-mode:text-zinc-600 uppercase tracking-wider">
                Academic Background
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-light tracking-tight text-white light-mode:text-zinc-900">
              Education & Coursework
            </h2>
            <p className="text-sm font-light text-zinc-400 light-mode:text-zinc-600 max-w-xl leading-relaxed mt-1">
              Academic credentials, degree programs, honors, and core computer science domain coursework.
            </p>
          </div>

          {/* Mode Switcher */}
          <div 
            role="tablist"
            aria-label="Education View Modes"
            className="flex flex-wrap items-center gap-1 p-1.5 rounded-xl bg-zinc-900/80 border border-white/[0.1] shrink-0 self-start md:self-auto select-none"
          >
            <button
              type="button"
              role="tab"
              aria-selected={viewMode === "minimal"}
              onClick={() => setViewMode("minimal")}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-mono transition-all duration-200 cursor-pointer ${
                viewMode === "minimal"
                  ? "bg-white/10 text-white font-medium border border-white/15 shadow-sm"
                  : "text-zinc-400 hover:text-zinc-200 hover:bg-white/[0.03]"
              }`}
            >
              1. Minimal List
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={viewMode === "grid"}
              onClick={() => setViewMode("grid")}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-mono transition-all duration-200 cursor-pointer ${
                viewMode === "grid"
                  ? "bg-white/10 text-white font-medium border border-white/15 shadow-sm"
                  : "text-zinc-400 hover:text-zinc-200 hover:bg-white/[0.03]"
              }`}
            >
              2. Two-Column
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={viewMode === "cards"}
              onClick={() => setViewMode("cards")}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-mono transition-all duration-200 cursor-pointer ${
                viewMode === "cards"
                  ? "bg-white/10 text-white font-medium border border-white/15 shadow-sm"
                  : "text-zinc-400 hover:text-zinc-200 hover:bg-white/[0.03]"
              }`}
            >
              3. Cards
            </button>
          </div>
        </div>

        {/* Selected Layout View */}
        <div className="w-full">
          {viewMode === "minimal" && <MinimalListLayout />}
          {viewMode === "grid" && <TwoColumnGridLayout />}
          {viewMode === "cards" && <CardFlowLayout />}
        </div>

      </div>
    </section>
  );
}

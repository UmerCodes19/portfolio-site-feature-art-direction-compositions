import { PROJECTS } from "@/data/projects";
import { ProjectsListClient } from "./ProjectsListClient";

export function ProjectsSection() {
  return (
    <section
      id="projects"
      className="relative w-full py-32 md:py-40 bg-[#080808] dark:bg-[#080808] light-mode:bg-[#F5F5F7] text-white dark:text-white light-mode:text-zinc-900 overflow-hidden transition-colors duration-400"
    >
      <ProjectsListClient projects={PROJECTS} />
    </section>
  );
}

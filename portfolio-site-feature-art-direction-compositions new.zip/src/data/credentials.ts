export interface CredentialItem {
  id: string;
  index: string;
  name: string;
  issuer: string;
  issueDate: string;
  credentialUrl?: string;
  skills: string[];
}

export const CREDENTIALS_DATA: CredentialItem[] = [
  {
    id: "cred-1",
    index: "01",
    name: "AWS Certified Solutions Architect",
    issuer: "Amazon Web Services (AWS)",
    issueDate: "2024",
    credentialUrl: "https://aws.amazon.com/certification/",
    skills: ["Cloud Infrastructure", "Distributed Systems", "AWS Services", "Security & IAM"]
  },
  {
    id: "cred-2",
    index: "02",
    name: "Meta Front-End Developer Professional",
    issuer: "Meta",
    issueDate: "2024",
    credentialUrl: "https://coursera.org",
    skills: ["Advanced React", "Next.js", "Web Performance", "UI Architecture"]
  },
  {
    id: "cred-3",
    index: "03",
    name: "Machine Learning Specialization",
    issuer: "DeepLearning.AI & Stanford",
    issueDate: "2023",
    credentialUrl: "https://coursera.org",
    skills: ["Neural Networks", "Supervised Learning", "PyTorch", "Model Evaluation"]
  },
  {
    id: "cred-4",
    index: "04",
    name: "PostgreSQL Database Architecture",
    issuer: "Enterprise Database Systems",
    issueDate: "2023",
    credentialUrl: "https://postgresql.org",
    skills: ["Query Optimization", "Database Indexing", "ACID Architecture", "Data Modeling"]
  }
];


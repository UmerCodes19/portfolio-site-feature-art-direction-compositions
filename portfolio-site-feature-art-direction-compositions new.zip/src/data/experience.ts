export interface ExperienceItem {
  id: string;
  index: string;
  company: string;
  role: string;
  duration: string;
  location: string;
  summary: string;
  responsibilities: string[];
  technologies: string[];
  featuredProject?: {
    title: string;
    description: string;
  };
}

export const EXPERIENCE_DATA: ExperienceItem[] = [
  {
    id: "exp-1",
    index: "01",
    company: "Software Architecture & Systems",
    role: "Software Engineer",
    duration: "2024 — Present",
    location: "Remote",
    summary: "Architecting core web applications, high-throughput REST APIs, responsive frontend systems, and state management pipelines.",
    responsibilities: [
      "Engineered high-performance web applications using TypeScript, React, and Next.js.",
      "Built resilient RESTful microservices and backend data pipelines.",
      "Optimized frontend render performance, achieving 98+ Lighthouse scores across major routes.",
      "Partnered with design lead to build and enforce a dark-theme system token library."
    ],
    technologies: ["TypeScript", "React", "Next.js", "Node.js", "Tailwind CSS", "PostgreSQL"],
    featuredProject: {
      title: "Distributed Data Engine",
      description: "Real-time stream processing platform for high-concurrency client updates."
    }
  },
  {
    id: "exp-2",
    index: "02",
    company: "Digital Product Labs",
    role: "Frontend & UI/UX Engineer",
    duration: "2023 — 2024",
    location: "Karachi, Pakistan",
    summary: "Built reusable UI component libraries, client state architectures, and intuitive user authentication workflows.",
    responsibilities: [
      "Designed and documented an enterprise React component library with strict accessibility compliance.",
      "Implemented secure OAuth 2.0 authentication flows and persistent session handlers.",
      "Maintained 90%+ unit test coverage and eliminated critical client render bottlenecks.",
      "Led weekly code reviews and frontend performance audits."
    ],
    technologies: ["JavaScript (ES6+)", "React", "Redux Toolkit", "Framer Motion", "Jest", "CSS3"],
    featuredProject: {
      title: "Design System Tokens",
      description: "Multi-theme design token package powering 4 internal web applications."
    }
  },
  {
    id: "exp-3",
    index: "03",
    company: "Tech Systems",
    role: "Software Engineering Intern",
    duration: "2022 — 2023",
    location: "Karachi, Pakistan",
    summary: "Collaborated with senior engineers on web feature implementation, database queries, unit tests, and technical documentation.",
    responsibilities: [
      "Developed responsive client views and resolved cross-browser layout inconsistencies.",
      "Wrote comprehensive unit tests and automated integration test suites.",
      "Documented API contracts, component props, and developer setup guides."
    ],
    technologies: ["HTML5/CSS3", "JavaScript", "REST APIs", "Git", "Postman"],
    featuredProject: {
      title: "Internal Analytics Portal",
      description: "Lightweight metric monitoring dashboard for development team operations."
    }
  }
];


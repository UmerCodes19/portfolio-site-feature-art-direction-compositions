export interface EducationRecord {
  id: string;
  institution: string;
  degree: string;
  period: string;
  grade?: string;
  highlights?: string[];
}

export interface CourseworkCategory {
  category: string;
  courses: string[];
}

export const EDUCATION_RECORDS: EducationRecord[] = [
  {
    id: "bahria",
    institution: "Bahria University Karachi Campus",
    degree: "Bachelor of Software Engineering",
    period: "2023 — 2027 (Expected)",
    grade: "GPA: 3.86",
    highlights: [
      "Merit Scholarship (3rd, 5th Semester)",
      "Top positions in semester"
    ]
  },
  {
    id: "commecs",
    institution: "Commecs College",
    degree: "Intermediate Education (Pre-Engineering)",
    period: "2021 — 2023",
    grade: "79.09%"
  },
  {
    id: "guardians",
    institution: "The Guardians Cambridge Education System",
    degree: "Matriculation / O-Levels",
    period: "2007 — 2021"
  }
];

export const COURSEWORK_CATEGORIES: CourseworkCategory[] = [
  {
    category: "Software Engineering & Core CS",
    courses: [
      "Software Design & Architecture",
      "Software Construction",
      "Software Requirement Engineering",
      "Software Quality Engineering",
      "Data Structures & Algorithms",
      "Design & Analysis of Algorithms",
      "Human Computer Interaction",
      "Agile Development",
      "Object Oriented Programming"
    ]
  },
  {
    category: "Systems, Backend & Cloud",
    courses: [
      "Database Management Systems",
      "Operating Systems",
      "Computer Communication & Networks",
      "Cloud Computing",
      "Computer Architecture"
    ]
  },
  {
    category: "AI, Mobile & Embedded",
    courses: [
      "Machine Learning",
      "Mobile Application Development",
      "Embedded System Design"
    ]
  },
  {
    category: "Mathematics & Foundations",
    courses: [
      "Linear Algebra",
      "Applied Calculus",
      "Probability & Statistics",
      "Technical Writing & Presentation"
    ]
  }
];

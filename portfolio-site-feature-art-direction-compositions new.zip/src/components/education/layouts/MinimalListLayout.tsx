"use client";

import { EDUCATION_RECORDS, COURSEWORK_CATEGORIES } from "@/data/education";

export function MinimalListLayout() {
  return (
    <div className="w-full flex flex-col gap-16 md:gap-24 antialiased">
      {/* Education History List */}
      <div className="w-full flex flex-col divide-y divide-white/[0.08] border-y border-white/[0.08]">
        {EDUCATION_RECORDS.map((item) => (
          <div 
            key={item.id} 
            className="py-9 sm:py-12 px-2 sm:px-4 flex flex-col md:flex-row md:items-start justify-between gap-6 hover:bg-white/[0.01] transition-colors duration-200"
          >
            <div className="flex flex-col gap-2 min-w-0">
              <h3 className="text-2xl sm:text-3xl font-light tracking-tight text-white">
                {item.institution}
              </h3>
              <p className="text-base text-zinc-300 font-light">
                {item.degree}
              </p>

              {item.highlights && item.highlights.length > 0 && (
                <ul className="mt-3 space-y-2 text-xs sm:text-sm text-zinc-400 font-light">
                  {item.highlights.map((h, i) => (
                    <li key={i} className="flex items-center gap-2.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#af5bf0] shrink-0 opacity-80" />
                      <span>{h}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="flex flex-row md:flex-col items-baseline md:items-end justify-between md:justify-start gap-3 shrink-0 font-mono text-xs text-zinc-400">
              <span>{item.period}</span>
              {item.grade && (
                <span className="px-3 py-1 rounded-md bg-[#af5bf0]/10 border border-[#af5bf0]/30 text-[#af5bf0] font-medium tracking-tight select-none">
                  {item.grade}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Relevant Coursework */}
      <div className="w-full flex flex-col gap-8">
        <h4 className="text-xs font-mono text-zinc-500 uppercase tracking-widest select-none">
          Relevant Domain Coursework
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {COURSEWORK_CATEGORIES.map((cat, idx) => (
            <div key={idx} className="flex flex-col gap-3.5">
              <h5 className="text-xs font-mono text-zinc-400 font-medium">
                {cat.category}
              </h5>
              <div className="flex flex-wrap gap-2">
                {cat.courses.map((course) => (
                  <span
                    key={course}
                    className="px-3 py-1 text-xs font-mono rounded-md bg-white/[0.03] border border-white/[0.08] text-zinc-300 hover:border-white/20 hover:text-white hover:bg-white/[0.05] transition-all duration-200 cursor-default select-none"
                  >
                    {course}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}


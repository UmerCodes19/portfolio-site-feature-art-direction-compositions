"use client";

import { EDUCATION_RECORDS, COURSEWORK_CATEGORIES } from "@/data/education";

export function SplitDossierLayout() {
  return (
    <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-10 antialiased">
      <div className="flex flex-col gap-6">
        {EDUCATION_RECORDS.map((item) => (
          <div key={item.id} className="p-4 rounded-lg bg-zinc-900/20 border border-white/[0.06]">
            <h3 className="text-base font-medium text-zinc-100">{item.institution}</h3>
            <p className="text-xs text-zinc-400 font-light">{item.degree}</p>
            <span className="text-xs font-mono text-zinc-500">{item.period}</span>
          </div>
        ))}
      </div>
      <div className="flex flex-col gap-4">
        {COURSEWORK_CATEGORIES.map((cat, idx) => (
          <div key={idx} className="flex flex-col gap-2">
            <h4 className="text-xs font-mono text-zinc-400">{cat.category}</h4>
            <div className="flex flex-wrap gap-1.5">
              {cat.courses.map((c) => (
                <span key={c} className="px-2 py-1 text-xs font-mono rounded bg-white/[0.02] border border-white/[0.06] text-zinc-300">
                  {c}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

"use client";

import { EDUCATION_RECORDS, COURSEWORK_CATEGORIES } from "@/data/education";

export function AsymmetricFlowLayout() {
  return (
    <div className="w-full flex flex-col gap-12 antialiased">
      <div className="flex flex-col gap-6">
        {EDUCATION_RECORDS.map((item) => (
          <div key={item.id} className="p-6 rounded-lg bg-zinc-900/30 border border-white/[0.06] flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs font-mono text-zinc-500">
              <span>{item.period}</span>
              {item.grade && <span className="text-[#af5bf0]">{item.grade}</span>}
            </div>
            <h3 className="text-xl font-medium text-zinc-100">{item.institution}</h3>
            <p className="text-sm text-zinc-400 font-light">{item.degree}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 border-t border-white/[0.08]">
        {COURSEWORK_CATEGORIES.map((cat, idx) => (
          <div key={idx} className="flex flex-col gap-2">
            <h4 className="text-xs font-mono text-zinc-400">{cat.category}</h4>
            <div className="flex flex-wrap gap-2">
              {cat.courses.map((course) => (
                <span key={course} className="px-2 py-1 text-xs font-mono rounded bg-white/[0.02] border border-white/[0.06] text-zinc-300">
                  {course}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

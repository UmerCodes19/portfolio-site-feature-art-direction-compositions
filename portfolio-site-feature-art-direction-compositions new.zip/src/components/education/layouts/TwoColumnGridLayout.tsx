"use client";

import { EDUCATION_RECORDS, COURSEWORK_CATEGORIES } from "@/data/education";

export function TwoColumnGridLayout() {
  return (
    <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 antialiased">
      {/* Left Column: Academic Credentials */}
      <div className="lg:col-span-5 flex flex-col gap-8">
        <h4 className="text-xs font-mono text-zinc-500 uppercase tracking-widest select-none">
          Academic Credentials
        </h4>

        <div className="flex flex-col gap-6">
          {EDUCATION_RECORDS.map((item) => (
            <div key={item.id} className="flex flex-col gap-2.5 p-6 rounded-2xl bg-zinc-900/40 border border-white/[0.08] hover:border-white/20 transition-all duration-300">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-mono text-zinc-400">{item.period}</span>
                {item.grade && (
                  <span className="text-xs font-mono text-[#af5bf0] font-medium px-2.5 py-0.5 rounded bg-[#af5bf0]/10 border border-[#af5bf0]/20">
                    {item.grade}
                  </span>
                )}
              </div>
              <h3 className="text-xl font-medium text-white tracking-tight mt-1">
                {item.institution}
              </h3>
              <p className="text-sm text-zinc-300 font-light">
                {item.degree}
              </p>

              {item.highlights && item.highlights.length > 0 && (
                <ul className="mt-2 space-y-1.5 text-xs text-zinc-400 font-light pt-3 border-t border-white/[0.06]">
                  {item.highlights.map((h, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#af5bf0] opacity-80" />
                      <span>{h}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Right Column: Coursework Grid */}
      <div className="lg:col-span-7 flex flex-col gap-8">
        <h4 className="text-xs font-mono text-zinc-500 uppercase tracking-widest select-none">
          Core Coursework
        </h4>

        <div className="flex flex-col gap-7">
          {COURSEWORK_CATEGORIES.map((cat, idx) => (
            <div key={idx} className="flex flex-col gap-3">
              <h5 className="text-xs font-mono text-zinc-300 font-medium">
                {cat.category}
              </h5>
              <div className="flex flex-wrap gap-2">
                {cat.courses.map((course) => (
                  <span
                    key={course}
                    className="px-3 py-1 text-xs font-mono rounded-md bg-white/[0.03] border border-white/[0.08] text-zinc-300 hover:border-white/20 hover:text-white transition-all select-none"
                  >
                    {course}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}


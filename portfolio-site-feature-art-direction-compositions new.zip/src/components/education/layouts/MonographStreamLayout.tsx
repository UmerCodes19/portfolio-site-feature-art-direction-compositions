"use client";

import { EDUCATION_RECORDS, COURSEWORK_CATEGORIES } from "@/data/education";

export function MonographStreamLayout() {
  return (
    <div className="w-full flex flex-col gap-10 antialiased">
      {EDUCATION_RECORDS.map((item) => (
        <div key={item.id} className="py-6 border-b border-white/[0.08] flex flex-col md:flex-row justify-between gap-4">
          <div>
            <h3 className="text-lg font-medium text-zinc-100">{item.institution}</h3>
            <p className="text-xs text-zinc-400 font-light">{item.degree}</p>
          </div>
          <div className="font-mono text-xs text-zinc-500">{item.period}</div>
        </div>
      ))}
      <div className="flex flex-col gap-4">
        {COURSEWORK_CATEGORIES.map((cat, idx) => (
          <div key={idx} className="flex flex-col gap-2">
            <h4 className="text-xs font-mono text-zinc-400">{cat.category}</h4>
            <div className="flex flex-wrap gap-2">
              {cat.courses.map((c) => (
                <span key={c} className="px-2 py-1 text-xs font-mono rounded bg-white/[0.02] border border-white/[0.06] text-zinc-300">
                  {c}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

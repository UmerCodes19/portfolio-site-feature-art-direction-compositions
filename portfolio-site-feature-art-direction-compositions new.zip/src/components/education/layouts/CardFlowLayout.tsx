"use client";

import { EDUCATION_RECORDS, COURSEWORK_CATEGORIES } from "@/data/education";

export function CardFlowLayout() {
  return (
    <div className="w-full flex flex-col gap-12 antialiased">
      {/* Featured Primary Degree Card */}
      {EDUCATION_RECORDS.slice(0, 1).map((item) => (
        <div 
          key={item.id} 
          className="p-8 sm:p-10 rounded-2xl bg-zinc-900/50 border border-white/[0.08] hover:border-white/20 transition-all duration-300 flex flex-col gap-6"
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-white/[0.08]">
            <div className="flex flex-col gap-1.5">
              <span className="text-xs font-mono text-[#af5bf0] uppercase tracking-wider">
                {item.degree}
              </span>
              <h3 className="text-2xl sm:text-3xl font-light tracking-tight text-white">
                {item.institution}
              </h3>
            </div>

            <div className="flex items-center gap-3 text-xs font-mono text-zinc-400">
              <span>{item.period}</span>
              {item.grade && (
                <span className="px-3 py-1 rounded-md bg-[#af5bf0]/10 border border-[#af5bf0]/30 text-[#af5bf0] font-medium select-none">
                  {item.grade}
                </span>
              )}
            </div>
          </div>

          {item.highlights && item.highlights.length > 0 && (
            <div className="flex flex-col gap-3">
              <span className="text-xs font-mono text-zinc-500 uppercase tracking-widest select-none">
                Highlights & Honors
              </span>
              <div className="flex flex-wrap gap-4 text-xs sm:text-sm text-zinc-300 font-light">
                {item.highlights.map((h, i) => (
                  <div key={i} className="flex items-center gap-2.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#af5bf0]" />
                    <span>{h}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ))}

      {/* Secondary Institutions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {EDUCATION_RECORDS.slice(1).map((item) => (
          <div 
            key={item.id} 
            className="p-6 sm:p-8 rounded-2xl bg-zinc-900/30 border border-white/[0.08] hover:border-white/20 transition-all duration-300 flex flex-col gap-3"
          >
            <div className="flex items-center justify-between gap-2 text-xs font-mono text-zinc-400">
              <span>{item.period}</span>
              {item.grade && <span className="text-[#af5bf0] font-medium">{item.grade}</span>}
            </div>
            <h4 className="text-lg font-medium text-white tracking-tight">
              {item.institution}
            </h4>
            <p className="text-xs sm:text-sm text-zinc-400 font-light">
              {item.degree}
            </p>
          </div>
        ))}
      </div>

      {/* Coursework Stream */}
      <div className="pt-6 flex flex-col gap-6">
        <h4 className="text-xs font-mono text-zinc-500 uppercase tracking-widest select-none">
          Coursework & Domain Knowledge
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {COURSEWORK_CATEGORIES.map((cat, idx) => (
            <div key={idx} className="flex flex-col gap-3 p-5 rounded-xl bg-white/[0.015] border border-white/[0.06] hover:border-white/15 transition-all">
              <h5 className="text-xs font-mono text-zinc-300 font-medium">
                {cat.category}
              </h5>
              <ul className="space-y-2 text-xs text-zinc-400 font-light">
                {cat.courses.slice(0, 5).map((course) => (
                  <li key={course} className="flex items-center gap-2 truncate">
                    <span className="w-1 h-1 rounded-full bg-[#af5bf0] shrink-0 opacity-70" />
                    <span className="truncate">{course}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}


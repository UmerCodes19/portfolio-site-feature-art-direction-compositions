"use client";

import { ArrowUpRight } from "lucide-react";
import { ExperienceItem } from "@/data/experience";

interface StackedLayoutProps {
  items: ExperienceItem[];
}

export function StackedLayout({ items }: StackedLayoutProps) {
  return (
    <div className="w-full flex flex-col gap-8 md:gap-12 antialiased">
      {items.map((item) => (
        <div
          key={item.id}
          className="w-full p-6 md:p-10 rounded-2xl bg-zinc-900/40 border border-white/[0.08] hover:border-white/20 transition-all duration-300 flex flex-col gap-7"
        >
          {/* Card Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-white/[0.08]">
            <div className="flex flex-col gap-1">
              <div className="flex items-center gap-3">
                <span className="font-mono text-xs text-zinc-500">
                  {item.index}.
                </span>
                <h3 className="text-xl md:text-2xl font-medium text-white tracking-tight">
                  {item.role}
                </h3>
              </div>
              <span className="text-base font-light text-zinc-400">
                {item.company}
              </span>
            </div>

            <div className="flex items-center gap-3 text-xs text-zinc-400 font-mono">
              <span>{item.duration}</span>
              <span className="text-zinc-700">•</span>
              <span>{item.location}</span>
            </div>
          </div>

          {/* Card Body */}
          <p className="text-base text-zinc-300 font-light leading-relaxed max-w-3xl">
            {item.summary}
          </p>

          {/* Responsibilities */}
          <div className="flex flex-col gap-3">
            <h4 className="text-xs font-mono tracking-widest text-zinc-500 uppercase select-none">
              Responsibilities
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm font-light text-zinc-300 leading-relaxed">
              {item.responsibilities.map((resp, idx) => (
                <li key={idx} className="flex items-start gap-3">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#af5bf0] mt-2 shrink-0 opacity-80" />
                  <span>{resp}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Technologies */}
          <div className="flex flex-col gap-3">
            <h4 className="text-xs font-mono tracking-widest text-zinc-500 uppercase select-none">
              Technologies & Stack
            </h4>
            <div className="flex flex-wrap gap-2">
              {item.technologies.map((tech) => (
                <span
                  key={tech}
                  className="px-3 py-1 text-xs font-mono rounded-md bg-white/[0.03] border border-white/[0.08] text-zinc-300 hover:border-white/20 hover:text-white transition-all select-none"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>

          {/* Featured Project */}
          {item.featuredProject && (
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.08] hover:border-[#af5bf0]/40 transition-all flex flex-col gap-1 group/link cursor-pointer">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-mono text-[#af5bf0] uppercase tracking-wider">
                  Featured Project
                </span>
                <ArrowUpRight className="w-3.5 h-3.5 text-zinc-500 group-hover/link:text-[#af5bf0] transition-colors" />
              </div>
              <h5 className="text-sm font-medium text-zinc-200 group-hover/link:text-white transition-colors">
                {item.featuredProject.title}
              </h5>
              <p className="text-xs font-light text-zinc-400">
                {item.featuredProject.description}
              </p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}


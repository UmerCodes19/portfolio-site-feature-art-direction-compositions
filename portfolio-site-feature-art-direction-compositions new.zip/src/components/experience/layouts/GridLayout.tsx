"use client";

import { ArrowUpRight } from "lucide-react";
import { ExperienceItem } from "@/data/experience";

interface GridLayoutProps {
  items: ExperienceItem[];
}

export function GridLayout({ items }: GridLayoutProps) {
  return (
    <div className="w-full flex flex-col gap-16 md:gap-24 antialiased">
      {items.map((item, index) => (
        <article
          key={item.id}
          className={`w-full flex flex-col lg:flex-row items-start justify-between gap-8 lg:gap-16 ${
            index < items.length - 1 ? "pb-16 md:pb-24 border-b border-white/[0.08]" : ""
          }`}
        >
          {/* Left Side: Meta & Role Info */}
          <div className="w-full lg:w-1/3 flex flex-col gap-2 shrink-0">
            <span className="font-mono text-xs text-zinc-500">
              {item.index}.
            </span>
            <h3 className="text-xl md:text-2xl font-medium text-zinc-100 tracking-tight">
              {item.role}
            </h3>
            <span className="text-base text-zinc-400 font-light">
              {item.company}
            </span>
            <div className="flex items-center gap-3 text-xs text-zinc-400 mt-2 font-mono">
              <span>{item.duration}</span>
              <span className="text-zinc-700">•</span>
              <span>{item.location}</span>
            </div>
          </div>

          {/* Right Side: Engineering Details */}
          <div className="w-full lg:w-2/3 flex flex-col gap-7 text-zinc-300">
            <p className="text-base font-light text-zinc-300 leading-relaxed max-w-2xl">
              {item.summary}
            </p>

            {/* Responsibilities */}
            <div className="flex flex-col gap-3">
              <h4 className="text-xs font-mono tracking-widest text-zinc-500 uppercase select-none">
                Responsibilities
              </h4>
              <ul className="space-y-2.5 text-xs sm:text-sm font-light text-zinc-300 leading-relaxed">
                {item.responsibilities.map((resp, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#af5bf0] mt-2 shrink-0 opacity-80" />
                    <span>{resp}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Technologies */}
            <div className="flex flex-col gap-3">
              <h4 className="text-xs font-mono tracking-widest text-zinc-500 uppercase select-none">
                Technologies & Stack
              </h4>
              <div className="flex flex-wrap gap-2">
                {item.technologies.map((tech) => (
                  <span
                    key={tech}
                    className="px-3 py-1 text-xs font-mono rounded-md bg-white/[0.03] border border-white/[0.08] text-zinc-300 hover:border-white/20 hover:text-white transition-all select-none"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            {/* Featured Project */}
            {item.featuredProject && (
              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.08] hover:border-[#af5bf0]/40 transition-all flex flex-col gap-1 max-w-xl group/link cursor-pointer">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-mono text-[#af5bf0] uppercase tracking-wider">
                    Featured Project
                  </span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-zinc-500 group-hover/link:text-[#af5bf0] transition-colors" />
                </div>
                <h5 className="text-sm font-medium text-zinc-200 group-hover/link:text-white transition-colors">
                  {item.featuredProject.title}
                </h5>
                <p className="text-xs font-light text-zinc-400">
                  {item.featuredProject.description}
                </p>
              </div>
            )}
          </div>
        </article>
      ))}
    </div>
  );
}


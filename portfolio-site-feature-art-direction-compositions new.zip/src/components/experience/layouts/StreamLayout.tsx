"use client";

import { useState } from "react";
import { ChevronDown, ArrowUpRight } from "lucide-react";
import { ExperienceItem } from "@/data/experience";

interface StreamLayoutProps {
  items: ExperienceItem[];
}

export function StreamLayout({ items }: StreamLayoutProps) {
  const [expandedId, setExpandedId] = useState<string | null>(items[0]?.id || null);

  const toggleExpand = (id: string) => {
    setExpandedId((prev) => (prev === id ? null : id));
  };

  return (
    <div className="w-full flex flex-col divide-y divide-white/[0.08] border-y border-white/[0.08] antialiased">
      {items.map((item) => {
        const isExpanded = expandedId === item.id;

        return (
          <div key={item.id} className="w-full transition-all duration-300 hover:bg-white/[0.015]">
            {/* Clickable Header Row */}
            <button
              type="button"
              aria-expanded={isExpanded}
              onClick={() => toggleExpand(item.id)}
              className="w-full py-7 md:py-9 px-4 flex flex-col md:flex-row md:items-center justify-between gap-4 text-left outline-none focus-visible:ring-1 focus-visible:ring-[#af5bf0]/50 select-none cursor-pointer"
            >
              <div className="flex flex-col md:flex-row md:items-baseline gap-2 md:gap-6 min-w-0">
                <span className="font-mono text-xs text-zinc-500 shrink-0">
                  {item.index}.
                </span>
                <h3 className="text-xl md:text-2xl font-normal text-zinc-100 group-hover:text-white tracking-tight">
                  {item.role}
                </h3>
                <span className="text-sm font-light text-zinc-400">
                  {item.company}
                </span>
              </div>

              <div className="flex items-center justify-between md:justify-end gap-6 text-xs font-mono text-zinc-400 shrink-0">
                <div className="flex items-center gap-3">
                  <span>{item.duration}</span>
                  <span className="text-zinc-700">•</span>
                  <span>{item.location}</span>
                </div>

                <div className={`w-8 h-8 rounded-full border border-white/[0.08] flex items-center justify-center transition-all duration-300 ${isExpanded ? "bg-[#af5bf0]/15 text-[#af5bf0] border-[#af5bf0]/40" : "text-zinc-400"}`}>
                  <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${isExpanded ? "rotate-180" : ""}`} />
                </div>
              </div>
            </button>

            {/* Expandable Content Panel */}
            {isExpanded && (
              <div className="pb-10 px-4 md:px-8 flex flex-col gap-6 text-zinc-300 antialiased">
                <p className="text-base font-light text-zinc-300 leading-relaxed max-w-3xl">
                  {item.summary}
                </p>

                {/* Responsibilities */}
                <div className="flex flex-col gap-3">
                  <h4 className="text-xs font-mono tracking-widest text-zinc-500 uppercase select-none">
                    Responsibilities
                  </h4>
                  <ul className="space-y-2.5 text-xs sm:text-sm font-light text-zinc-300 leading-relaxed">
                    {item.responsibilities.map((resp, idx) => (
                      <li key={idx} className="flex items-start gap-3">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#af5bf0] mt-2 shrink-0 opacity-80" />
                        <span>{resp}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Technologies */}
                <div className="flex flex-col gap-3">
                  <h4 className="text-xs font-mono tracking-widest text-zinc-500 uppercase select-none">
                    Technologies & Stack
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {item.technologies.map((tech) => (
                      <span
                        key={tech}
                        className="px-3 py-1 text-xs font-mono rounded-md bg-white/[0.03] border border-white/[0.08] text-zinc-300 hover:border-white/20 hover:text-white transition-all select-none"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Featured Project Direct Link */}
                {item.featuredProject && (
                  <div className="pt-2">
                    <div className="inline-flex items-center gap-4 p-4 rounded-xl border border-white/[0.08] hover:border-[#af5bf0]/40 bg-white/[0.02] hover:bg-white/[0.04] transition-all duration-200 cursor-pointer group/link">
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-mono text-[#af5bf0] uppercase tracking-wider">
                          Featured Project
                        </span>
                        <span className="text-sm font-medium text-zinc-100 group-hover/link:text-white transition-colors">
                          {item.featuredProject.title} — <span className="font-light text-zinc-400">{item.featuredProject.description}</span>
                        </span>
                      </div>
                      <ArrowUpRight className="w-4 h-4 text-zinc-400 group-hover/link:text-[#af5bf0] transition-colors shrink-0" />
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}


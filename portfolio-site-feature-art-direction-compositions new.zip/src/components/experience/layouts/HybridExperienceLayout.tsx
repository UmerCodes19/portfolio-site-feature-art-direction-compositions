"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, ArrowUpRight } from "lucide-react";
import { ExperienceItem } from "@/data/experience";

interface HybridExperienceLayoutProps {
  items: ExperienceItem[];
}

export function HybridExperienceLayout({ items }: HybridExperienceLayoutProps) {
  // All items start contracted by default per design specification
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const toggleExpand = (id: string) => {
    setExpandedId((prev) => (prev === id ? null : id));
  };

  return (
    <div className="w-full flex flex-col border-y border-white/[0.08] divide-y divide-white/[0.08] antialiased">
      {items.map((item) => {
        const isExpanded = expandedId === item.id;

        return (
          <div
            key={item.id}
            className={`group relative w-full transition-all duration-300 border-l-2 ${
              isExpanded 
                ? "bg-white/[0.02] border-l-[#af5bf0]" 
                : "border-l-transparent hover:border-l-white/20 hover:bg-white/[0.01]"
            }`}
          >
            {/* Clickable Header Row */}
            <button
              type="button"
              aria-expanded={isExpanded}
              onClick={() => toggleExpand(item.id)}
              className="w-full py-8 md:py-10 px-4 sm:px-6 flex flex-col md:flex-row md:items-center justify-between gap-4 text-left outline-none focus-visible:ring-1 focus-visible:ring-[#af5bf0]/50 select-none cursor-pointer"
            >
              {/* Role & Company */}
              <div className="flex flex-col md:flex-row md:items-baseline gap-2 md:gap-6 min-w-0">
                <span className="font-mono text-xs text-zinc-500 shrink-0">
                  {item.index}.
                </span>
                <h3
                  className={`text-xl md:text-2xl font-normal tracking-tight transition-colors duration-200 ${
                    isExpanded ? "text-white font-medium" : "text-zinc-200 group-hover:text-white"
                  }`}
                >
                  {item.role}
                </h3>
                <span className="text-sm md:text-base font-light text-zinc-400">
                  {item.company}
                </span>
              </div>

              {/* Meta & Expand Toggle Icon */}
              <div className="flex items-center justify-between md:justify-end gap-6 shrink-0">
                <div className="flex items-center gap-3 text-xs text-zinc-400 font-mono">
                  <span>{item.duration}</span>
                  <span className="text-zinc-700">•</span>
                  <span>{item.location}</span>
                </div>

                <div
                  className={`w-8 h-8 rounded-full border flex items-center justify-center transition-all duration-300 ${
                    isExpanded
                      ? "bg-[#af5bf0]/15 text-[#af5bf0] border-[#af5bf0]/40"
                      : "bg-transparent text-zinc-400 border-white/[0.08] group-hover:text-white group-hover:border-white/25 group-hover:bg-white/[0.04]"
                  }`}
                >
                  <motion.div
                    animate={{ rotate: isExpanded ? 180 : 0 }}
                    transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </motion.div>
                </div>
              </div>
            </button>

            {/* Contracting & Expanding Motion Container */}
            <AnimatePresence initial={false}>
              {isExpanded && (
                <motion.div
                  key="content"
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{
                    height: { duration: 0.35, ease: [0.16, 1, 0.3, 1] },
                    opacity: { duration: 0.25, ease: "linear" },
                  }}
                  className="overflow-hidden"
                >
                  <div className="px-4 sm:px-6 pb-10 pt-2 flex flex-col gap-7 max-w-4xl text-zinc-300">
                    {/* Summary */}
                    <p className="text-base text-zinc-300 font-light leading-relaxed max-w-3xl">
                      {item.summary}
                    </p>

                    {/* Key Responsibilities */}
                    <div className="flex flex-col gap-3">
                      <h4 className="text-xs font-mono tracking-widest text-zinc-500 uppercase select-none">
                        Core Engineering Responsibilities
                      </h4>
                      <ul className="space-y-2.5 text-xs sm:text-sm font-light text-zinc-300 leading-relaxed">
                        {item.responsibilities.map((resp, idx) => (
                          <li key={idx} className="flex items-start gap-3">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#af5bf0] mt-2 shrink-0 opacity-80" />
                            <span className="text-zinc-300">{resp}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Technologies & Domain Tooling */}
                    <div className="flex flex-col gap-3">
                      <h4 className="text-xs font-mono tracking-widest text-zinc-500 uppercase select-none">
                        Technologies & Infrastructure
                      </h4>
                      <div className="flex flex-wrap items-center gap-2">
                        {item.technologies.map((tech) => (
                          <span
                            key={tech}
                            className="px-3 py-1 text-xs font-mono rounded-md bg-white/[0.03] border border-white/[0.08] text-zinc-300 hover:border-white/20 hover:text-white transition-all duration-200 select-none"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Featured Project Direct Link */}
                    {item.featuredProject && (
                      <div className="pt-2">
                        <div className="inline-flex items-center gap-4 p-4 rounded-xl border border-white/[0.08] hover:border-[#af5bf0]/40 bg-white/[0.02] hover:bg-white/[0.04] transition-all duration-200 cursor-pointer group/link">
                          <div className="flex flex-col gap-0.5">
                            <span className="text-xs font-mono text-[#af5bf0] uppercase tracking-wider">
                              Featured Engineering Initiative
                            </span>
                            <span className="text-sm font-medium text-zinc-100 group-hover/link:text-white transition-colors">
                              {item.featuredProject.title} — <span className="font-light text-zinc-400">{item.featuredProject.description}</span>
                            </span>
                          </div>
                          <ArrowUpRight className="w-4 h-4 text-zinc-400 group-hover/link:text-[#af5bf0] group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5 transition-all shrink-0" />
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
}


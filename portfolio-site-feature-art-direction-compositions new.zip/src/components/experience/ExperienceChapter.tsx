"use client";

import { ExperienceItem } from "@/data/experience";

interface ExperienceChapterProps {
  item: ExperienceItem;
  isLast: boolean;
}

export function ExperienceChapter({ item, isLast }: ExperienceChapterProps) {
  return (
    <article className={`relative w-full ${isLast ? "pb-12" : "pb-16"}`}>
      <div className="flex flex-col gap-2">
        <h3 className="text-lg font-medium text-zinc-100">{item.role}</h3>
        <span className="text-sm text-zinc-400">{item.company}</span>
      </div>
    </article>
  );
}

"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, Copy, Check } from "lucide-react";
import { CONTACT_DATA } from "@/data/contact";

export function ContactSection() {
  const [copied, setCopied] = useState(false);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(CONTACT_DATA.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section
      id="contact"
      className="relative w-full py-28 md:py-40 bg-[#080808] text-white overflow-hidden"
    >
      <div className="relative w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Asymmetrical Editorial Composition */}
        <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 pb-24 border-b border-white/[0.08] antialiased">
          
          {/* Left Stage: Primary Contact Action & Hierarchy */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 flex flex-col gap-9"
          >
            {/* Header & Tag */}
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <span className="font-mono text-xs text-zinc-400 uppercase tracking-widest">
                  06. Contact
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#af5bf0]" />
                <span className="font-mono text-xs text-zinc-400 uppercase tracking-wider">
                  Get in Touch
                </span>
              </div>
              <h2 className="text-4xl sm:text-5xl md:text-6xl font-light tracking-tight text-white">
                Contact
              </h2>
            </div>

            {/* Supporting Paragraph */}
            <p className="text-base sm:text-lg font-light text-zinc-300 leading-relaxed max-w-xl">
              {CONTACT_DATA.closingStatement}
            </p>

            {/* Primary Email Action Stage */}
            <div className="flex flex-col gap-4 pt-2">
              <span className="text-xs font-mono text-zinc-500 uppercase tracking-widest select-none">
                Primary Email
              </span>

              <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                <a
                  href={`mailto:${CONTACT_DATA.email}`}
                  className="group inline-flex items-center gap-3 text-2xl sm:text-3xl md:text-4xl font-light tracking-tight text-white hover:text-[#FAFAFA] transition-colors"
                >
                  <span className="underline underline-offset-8 decoration-white/20 group-hover:decoration-[#af5bf0] transition-colors duration-300">
                    {CONTACT_DATA.email}
                  </span>
                  <ArrowUpRight className="w-6 h-6 text-zinc-400 group-hover:text-[#af5bf0] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all shrink-0" />
                </a>

                {/* Tactile Copy Button */}
                <button
                  type="button"
                  onClick={handleCopyEmail}
                  aria-label="Copy email address"
                  className="px-3.5 py-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] active:scale-95 border border-white/[0.1] hover:border-white/25 text-xs font-mono text-zinc-200 flex items-center gap-2 transition-all shrink-0 self-start sm:self-auto cursor-pointer select-none"
                  title="Copy email address to clipboard"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#af5bf0]" />
                      <span className="text-[#af5bf0] font-medium">Copied to Clipboard</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-zinc-400" />
                      <span>Copy Email</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Availability & Location Metadata */}
            <div className="flex flex-col gap-2.5 pt-8 border-t border-white/[0.06] max-w-xl">
              <div className="flex items-center gap-2.5 text-xs font-mono text-zinc-400">
                <span className="w-2 h-2 rounded-full bg-[#af5bf0] animate-pulse" />
                <span className="text-zinc-300 font-medium">Availability:</span>
                <span>{CONTACT_DATA.availability}</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs font-mono text-zinc-400">
                <span className="text-zinc-400 font-medium">Location:</span>
                <span>{CONTACT_DATA.location}</span>
              </div>
            </div>
          </motion.div>

          {/* Right Stage: Secondary Links */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.5, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 flex flex-col gap-6 lg:pl-10 lg:border-l lg:border-white/[0.08]"
          >
            <span className="text-xs font-mono text-zinc-500 uppercase tracking-widest select-none">
              Direct Channels & CV
            </span>

            <div className="flex flex-col divide-y divide-white/[0.08] border-y border-white/[0.08]">
              {CONTACT_DATA.socials.map((link) => (
                <a
                  key={link.name}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group py-5 px-2 flex items-center justify-between text-base text-zinc-300 hover:text-white transition-all hover:bg-white/[0.015]"
                >
                  <div className="flex flex-col gap-0.5">
                    <span className="font-medium group-hover:text-white transition-colors">
                      {link.name}
                    </span>
                    <span className="text-xs font-mono text-zinc-400 font-normal">
                      {link.label}
                    </span>
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-zinc-400 group-hover:text-[#af5bf0] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
                </a>
              ))}
            </div>
          </motion.div>

        </div>

        {/* Minimal Footer Anchor */}
        <div className="pt-10 flex flex-col sm:flex-row items-center justify-between text-xs font-mono text-zinc-400 gap-4 antialiased">
          <span>© {new Date().getFullYear()} Umer Quraishi</span>
          <span className="text-zinc-500">Software Engineer • Full-Stack Developer • UI/UX Designer</span>
        </div>

      </div>
    </section>
  );
}


import { PROJECTS } from "@/data/projects";
import { ProjectsListClient } from "./ProjectsListClient";

export function ProjectsSection() {
  return (
    <section
      id="projects"
      className="relative w-full py-32 md:py-40 bg-[#080808] text-white overflow-hidden"
    >
      <ProjectsListClient projects={PROJECTS} />
    </section>
  );
}

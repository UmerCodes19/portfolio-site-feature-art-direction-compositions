"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { motion, AnimatePresence, useSpring, MotionValue, useTransform } from "framer-motion";
import { Project } from "@/data/projects";

interface CursorPreviewProps {
  activeProject: Project | null;
  mouseX: MotionValue<number>;
  mouseY: MotionValue<number>;
  isReducedMotion: boolean;
}

export function CursorPreview({
  activeProject,
  mouseX,
  mouseY,
  isReducedMotion,
}: CursorPreviewProps) {
  const [isPointerFine, setIsPointerFine] = useState(false);

  // Heavy, weighted inertia motion without springiness or jitter
  // Mass: 1.2, Damping: 38, Stiffness: 90 produces smooth OS-like inertia interpolation
  const inertiaConfig = {
    stiffness: 90,
    damping: 38,
    mass: 1.2,
  };

  // Transform raw cursor position with a fixed 140px X-offset and -60px Y-offset
  // so the preview floats cleanly to the top-right, visually unobstructing the cursor and text
  const targetX = useTransform(mouseX, (x) => {
    if (typeof window === "undefined") return x + 140;
    const cardWidth = 320;
    if (x + 140 + cardWidth > window.innerWidth - 32) {
      return x - cardWidth - 40;
    }
    return x + 140;
  });

  const targetY = useTransform(mouseY, (y) => y - 60);

  const smoothX = useSpring(targetX, inertiaConfig);
  const smoothY = useSpring(targetY, inertiaConfig);

  useEffect(() => {
    const mediaQuery = window.matchMedia("(pointer: fine)");
    setIsPointerFine(mediaQuery.matches);

    const handleChange = (e: MediaQueryListEvent) => setIsPointerFine(e.matches);
    mediaQuery.addEventListener("change", handleChange);
    return () => mediaQuery.removeEventListener("change", handleChange);
  }, []);

  // Pointer device check & reduced motion check
  if (!isPointerFine || isReducedMotion) return null;

  return (
    <AnimatePresence>
      {activeProject && (
        <motion.div
          initial={{ opacity: 0, scale: 0.96, filter: "blur(4px)" }}
          animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
          exit={{ opacity: 0, scale: 0.96, filter: "blur(4px)" }}
          transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
          style={{
            position: "fixed",
            left: 0,
            top: 0,
            x: smoothX,
            y: smoothY,
            pointerEvents: "none",
            zIndex: 40,
          }}
          className="hidden md:block w-72 h-44 lg:w-80 lg:h-48"
        >
          {/* OS-like Weighted Inspector Window */}
          <div className="w-full h-full rounded-xl overflow-hidden shadow-2xl bg-zinc-950/95 border border-white/10 backdrop-blur-2xl relative ring-1 ring-white/5">
            <div className="relative w-full h-full overflow-hidden bg-zinc-950">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeProject.slug}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.16, ease: "easeOut" }}
                  className="relative w-full h-full"
                >
                  <Image
                    src={activeProject.coverImage}
                    alt={activeProject.title}
                    fill
                    sizes="(max-width: 1024px) 288px, 320px"
                    className="object-cover"
                  />
                  
                  {/* Clean OS Inspector Status Bar */}
                  <div className="absolute bottom-0 left-0 right-0 px-3 py-2 z-10 flex items-center justify-between bg-zinc-950/90 backdrop-blur-md border-t border-white/10">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="font-mono text-[10px] tracking-widest text-[#af5bf0] uppercase">
                        {activeProject.index}
                      </span>
                      <span className="w-1 h-1 rounded-full bg-[#af5bf0]" />
                      <h4 className="text-[11px] font-mono text-zinc-300 truncate">
                        {activeProject.title}
                      </h4>
                    </div>
                    <span className="text-[9px] font-mono text-zinc-400 tracking-wider uppercase px-1.5 py-0.5 rounded bg-white/5 border border-white/5 shrink-0">
                      {activeProject.category}
                    </span>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}


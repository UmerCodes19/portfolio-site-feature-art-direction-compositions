"use client";

import { useEffect, useRef, useState } from "react";
import { useMotionValue, useReducedMotion } from "framer-motion";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Project, PROJECTS } from "@/data/projects";
import { PROJECTS_MOTION } from "@/config/motion";
import { ProjectRow } from "./ProjectRow";
import { CursorPreview } from "./CursorPreview";
import { ProjectDetailModal } from "./ProjectDetailModal";

// Register GSAP ScrollTrigger plugin once
if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger);
}

interface ProjectsListClientProps {
  projects?: Project[];
}

export function ProjectsListClient({ projects = PROJECTS }: ProjectsListClientProps) {
  const [hoveredSlug, setHoveredSlug] = useState<string | null>(null);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Motion values for cursor position tracking (no re-renders on mousemove!)
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const isReducedMotion = useReducedMotion() ?? false;

  const activeProject = projects.find((p) => p.slug === hoveredSlug) || null;

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    mouseX.set(e.clientX);
    mouseY.set(e.clientY);
  };

  // GSAP ScrollTrigger row-enter animation
  useEffect(() => {
    if (isReducedMotion || !containerRef.current) return;

    const ctx = gsap.context(() => {
      const rows = containerRef.current?.querySelectorAll(".project-row-item");
      if (rows && rows.length > 0) {
        gsap.fromTo(
          rows,
          {
            opacity: 0,
            y: PROJECTS_MOTION.rowEnter.initialY,
          },
          {
            opacity: 1,
            y: 0,
            duration: PROJECTS_MOTION.rowEnter.duration,
            stagger: PROJECTS_MOTION.rowEnter.staggerStep,
            ease: "power2.out",
            scrollTrigger: {
              trigger: containerRef.current,
              start: "top 85%", // Triggers just before reaching full view (85% of viewport height)
              toggleActions: "play none none none", // Plays once on enter, does not replay/reverse on scroll change
            },
          }
        );
      }
    }, containerRef);

    return () => ctx.revert();
  }, [isReducedMotion]);

  return (
    <div
      onMouseMove={handleMouseMove}
      className="relative w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
    >
      {/* Section Header with Precision Typesetting */}
      <div className="relative z-10 flex flex-col md:flex-row md:items-end justify-between mb-12 md:mb-20 gap-6 pb-8 border-b border-white/[0.06] antialiased">
        <div className="flex flex-col gap-2.5">
          <div className="flex items-center gap-3">
            <span className="font-mono text-[11px] font-medium tracking-[0.28em] uppercase text-[#af5bf0] select-none">
              02. Selected Projects
            </span>
            <span className="w-1 h-1 rounded-full bg-[#af5bf0]" />
            <span className="font-mono text-[11px] tracking-[0.22em] text-zinc-500 uppercase tabular-nums select-none">
              {projects.length} Projects
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-light tracking-[-0.035em] text-zinc-100 leading-[1.08]">
            Selected Projects
          </h2>
        </div>
        <p className="text-xs sm:text-sm font-light text-zinc-400 max-w-md leading-[1.7] tracking-[0.015em]">
          Applications, software infrastructure, and digital products built with focus on engineering quality.
        </p>
      </div>

      {/* Vertical Exhibition List with GSAP ScrollTrigger row-enter Stagger */}
      <div
        ref={containerRef}
        className="relative z-10 flex flex-col space-y-4 md:space-y-6 divide-y divide-white/[0.03]"
      >
        {projects.map((project) => (
          <div key={project.slug} className="project-row-item pt-4 md:pt-6">
            <ProjectRow
              project={project}
              isHovered={hoveredSlug === project.slug}
              onHover={setHoveredSlug}
              onLeave={() => setHoveredSlug(null)}
              onSelect={setSelectedProject}
            />
          </div>
        ))}
      </div>

      {/* Cursor-Following Preview (Desktop spring trailing preview) */}
      <CursorPreview
        activeProject={activeProject}
        mouseX={mouseX}
        mouseY={mouseY}
        isReducedMotion={isReducedMotion}
      />

      {/* Morphing Detail View Modal */}
      <ProjectDetailModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
        isReducedMotion={isReducedMotion}
      />
    </div>
  );
}

"use client";

import Image from "next/image";
import { ArrowUpRight } from "lucide-react";
import { Project } from "@/data/projects";

interface ProjectRowProps {
  project: Project;
  isHovered: boolean;
  onHover: (slug: string) => void;
  onLeave: (slug: string) => void;
  onSelect: (project: Project) => void;
}

/**
 * Custom Optical Brand Identity Renderer for Each Independent Project Identity
 * Professionally typeset and optically balanced floating marks in open negative space.
 */
function RenderBrandIdentity({ project }: { project: Project }) {
  const slug = project.slug;

  // Projects with explicit PNG logo files: Optically scaled by brand silhouette
  if (project.logoUrl) {
    let containerStyle = "w-44 sm:w-56 md:w-64 h-20 sm:h-24";
    let imageStyle = "h-14 sm:h-18 md:h-20 w-auto object-contain";

    if (slug === "adhura") {
      containerStyle = "w-48 sm:w-64 md:w-72 h-20 sm:h-24";
      imageStyle = "h-14 sm:h-18 md:h-20 w-auto object-contain";
    } else if (slug === "algorhythms") {
      containerStyle = "w-44 sm:w-56 md:w-64 h-18 sm:h-22";
      imageStyle = "h-12 sm:h-16 md:h-18 w-auto object-contain";
    } else if (slug === "awwab") {
      containerStyle = "w-28 sm:w-36 md:w-40 h-24 sm:h-28 md:h-32";
      imageStyle = "h-20 sm:h-24 md:h-28 w-auto object-contain";
    } else if (slug === "bahria-chronicles") {
      containerStyle = "w-32 sm:w-40 md:w-44 h-20 sm:h-24";
      imageStyle = "h-16 sm:h-20 md:h-22 w-auto object-contain";
    } else if (slug === "solemates") {
      containerStyle = "w-24 sm:w-28 md:w-32 h-20 sm:h-24";
      imageStyle = "w-16 sm:w-20 md:w-22 h-16 sm:h-20 md:h-22 rounded-full object-cover shadow-lg";
    } else if (slug === "trace") {
      containerStyle = "w-32 sm:w-40 md:w-44 h-20 sm:h-24";
      imageStyle = "h-14 sm:h-18 md:h-20 w-auto object-contain";
    } else if (slug === "uummeed") {
      containerStyle = "w-44 sm:w-56 md:w-64 h-20 sm:h-24";
      imageStyle = "h-14 sm:h-18 md:h-20 w-auto object-contain";
    }

    return (
      <div className={`relative shrink-0 flex items-center justify-start p-1 ${containerStyle}`}>
        <Image
          src={project.logoUrl}
          alt={`${project.title} logo`}
          width={280}
          height={140}
          className={`${imageStyle} opacity-75 group-hover:opacity-100 filter grayscale group-hover:grayscale-0 transition-opacity duration-300 ease-out`}
        />
      </div>
    );
  }

  // Bespoke Typographic Brand Lockups: Professionally typeset with optical tracking and kerning
  if (slug === "maira") {
    return (
      <div className="relative w-44 sm:w-56 h-18 sm:h-22 shrink-0 flex items-center justify-start">
        <span className="font-mono text-2xl sm:text-3xl font-light tracking-[0.35em] text-zinc-400 group-hover:text-white uppercase transition-colors duration-300 antialiased">
          MAI<span className="font-semibold text-zinc-300 group-hover:text-white">RA</span>
        </span>
      </div>
    );
  }

  if (slug === "querytalk") {
    return (
      <div className="relative w-48 sm:w-60 h-18 sm:h-22 shrink-0 flex items-center justify-start">
        <span className="font-mono text-xl sm:text-2xl font-medium tracking-[0.28em] text-zinc-400 group-hover:text-white uppercase transition-colors duration-300 antialiased">
          QUERY TALK
        </span>
      </div>
    );
  }

  if (slug === "rahnumai") {
    return (
      <div className="relative w-48 sm:w-60 h-18 sm:h-22 shrink-0 flex items-center justify-start">
        <span className="font-mono text-xl sm:text-2xl font-light tracking-[0.32em] text-zinc-400 group-hover:text-white uppercase transition-colors duration-300 antialiased">
          RAHNUM<span className="font-bold text-white">AI</span>
        </span>
      </div>
    );
  }

  if (slug === "ubook") {
    return (
      <div className="relative w-44 sm:w-56 h-18 sm:h-22 shrink-0 flex items-center justify-start">
        <span className="font-mono text-2xl sm:text-3xl font-light tracking-[0.38em] text-zinc-400 group-hover:text-white uppercase transition-colors duration-300 antialiased">
          U<span className="font-semibold text-zinc-300 group-hover:text-white">BOOK</span>
        </span>
      </div>
    );
  }

  const initials = project.title.slice(0, 2).toUpperCase();
  return (
    <div className="relative w-36 sm:w-44 h-18 sm:h-22 shrink-0 flex items-center justify-start">
      <span className="font-mono text-xl sm:text-2xl font-bold tracking-[0.25em] text-zinc-400 group-hover:text-white uppercase transition-colors duration-300 antialiased">
        {initials}
      </span>
    </div>
  );
}

export function ProjectRow({
  project,
  isHovered,
  onHover,
  onLeave,
  onSelect,
}: ProjectRowProps) {
  const indexNum = parseInt(project.index, 10);
  const isEven = indexNum % 2 === 0;

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => onSelect(project)}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onSelect(project);
        }
      }}
      onMouseEnter={() => onHover(project.slug)}
      onMouseLeave={() => onLeave(project.slug)}
      onFocus={() => onHover(project.slug)}
      onBlur={() => onLeave(project.slug)}
      className={`group relative w-full ${
        isEven ? "py-12 md:py-14" : "py-14 md:py-18"
      } px-4 md:px-8 transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] cursor-pointer outline-none focus-visible:ring-1 focus-visible:ring-white/20`}
    >
      {/* Restrained Left Selection Indicator Pill */}
      <span
        className={`absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-8 rounded-r bg-[#af5bf0] transition-all duration-300 ease-out ${
          isHovered ? "opacity-100 scale-y-100" : "opacity-0 scale-y-50"
        }`}
      />

      {/* Subtle Row Hairline Accent on Hover */}
      <div
        className={`absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-[#af5bf0]/25 to-transparent pointer-events-none transition-opacity duration-500 ease-out ${
          isHovered ? "opacity-100" : "opacity-0"
        }`}
      />

      {/* Asymmetric Open Exhibition Layout — Professionally Typeset Typography */}
      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8 md:gap-12 antialiased">
        {/* Left: Hero Brand Stage & Quiet Secondary Title */}
        <div className="flex flex-col sm:flex-row sm:items-center gap-6 min-w-0 md:w-[360px] lg:w-[440px] shrink-0">
          <div className="flex items-center gap-4 sm:gap-6 min-w-0">
            <span className="font-mono text-xs tracking-[0.2em] text-zinc-600 group-hover:text-[#af5bf0] transition-colors duration-300 shrink-0 w-8 select-none tabular-nums">
              {project.index}.
            </span>
            <RenderBrandIdentity project={project} />
          </div>

          {/* Secondary Supporting Title — Elegant, Quiet Monospaced Caption */}
          <div className="flex flex-col min-w-0 pt-1 sm:pt-0">
            <h3 className="text-xs sm:text-sm font-mono tracking-[0.18em] uppercase text-zinc-500 group-hover:text-zinc-200 transition-colors duration-300 truncate">
              {project.title}
            </h3>
            <span className="text-[10px] font-mono tracking-[0.22em] text-zinc-600 uppercase mt-0.5 select-none">
              {project.year}
            </span>
          </div>
        </div>

        {/* Center: Quiet Editorial Tagline — Optimal Reading Measure & Line-Height */}
        <div className={`min-w-0 flex-1 ${isEven ? "max-w-[44ch]" : "max-w-[50ch]"}`}>
          <p className="text-xs sm:text-sm font-light leading-[1.7] tracking-[0.015em] text-zinc-500 group-hover:text-zinc-300 transition-colors duration-300">
            {project.tagline}
          </p>
        </div>

        {/* Right: Quieter Category Metadata & Action Indicator */}
        <div className="flex items-center justify-between md:justify-end gap-6 shrink-0 pt-2 md:pt-0">
          <div className="flex flex-col items-start md:items-end gap-1">
            <span className="text-[10px] font-mono tracking-[0.22em] text-zinc-600 group-hover:text-zinc-400 uppercase transition-colors select-none">
              {project.category}
            </span>
            <div className="hidden lg:flex items-center gap-2">
              {project.tags.slice(0, 2).map((tag) => (
                <span
                  key={tag}
                  className="text-[10px] font-mono tracking-[0.15em] text-zinc-700 group-hover:text-zinc-500 transition-colors"
                >
                  #{tag}
                </span>
              ))}
            </div>
          </div>

          <div className="w-8 h-8 rounded-full bg-zinc-900/60 border border-white/[0.06] group-hover:border-[#af5bf0]/40 flex items-center justify-center text-zinc-600 group-hover:text-[#af5bf0] transition-all duration-300 ease-out shrink-0">
            <ArrowUpRight className="w-3.5 h-3.5" />
          </div>
        </div>
      </div>
    </div>
  );
}





"use client";

import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { CREDENTIALS_DATA } from "@/data/credentials";

export function CredentialsSection() {
  return (
    <section
      id="credentials"
      className="relative w-full py-28 md:py-40 bg-[#080808] text-white overflow-hidden"
    >
      <div className="relative w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col gap-2.5 mb-14 md:mb-20 pb-8 border-b border-white/[0.08] antialiased">
          <div className="flex items-center gap-3">
            <span className="font-mono text-xs text-zinc-400 uppercase tracking-widest">
              05. Certifications
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#af5bf0]" />
            <span className="font-mono text-xs text-zinc-400 uppercase tracking-wider">
              Technical Verification
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-light tracking-tight text-white">
            Certifications
          </h2>
          <p className="text-sm font-light text-zinc-400 max-w-xl leading-relaxed mt-1">
            Verified professional engineering certifications, specialized domain credentials, and technical accreditations.
          </p>
        </div>

        {/* Integrated Vertical Stream */}
        <div className="w-full flex flex-col border-y border-white/[0.08] divide-y divide-white/[0.08] antialiased">
          {CREDENTIALS_DATA.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.4, delay: index * 0.08, ease: [0.16, 1, 0.3, 1] }}
              className="group relative py-8 sm:py-10 px-4 sm:px-6 flex flex-col md:flex-row md:items-center justify-between gap-6 transition-all duration-300 border-l-2 border-l-transparent hover:border-l-[#af5bf0] hover:bg-white/[0.015]"
            >
              {/* Left Stage: Index, Certification Name & Issuer */}
              <div className="flex flex-col sm:flex-row sm:items-baseline gap-3 sm:gap-6 min-w-0 md:w-1/3">
                <span className="font-mono text-xs text-zinc-500 shrink-0 select-none">
                  {item.index}.
                </span>
                <div className="flex flex-col gap-1 min-w-0">
                  <h3 className="text-lg sm:text-xl font-medium text-zinc-100 group-hover:text-white transition-colors tracking-tight truncate">
                    {item.name}
                  </h3>
                  <span className="text-xs sm:text-sm text-zinc-400 font-light truncate">
                    {item.issuer}
                  </span>
                </div>
              </div>

              {/* Center: Skills Covered */}
              <div className="flex flex-wrap items-center gap-2 max-w-md md:w-1/3">
                {item.skills.map((skill) => (
                  <span
                    key={skill}
                    className="px-3 py-1 text-xs font-mono rounded-md bg-white/[0.03] border border-white/[0.08] text-zinc-300 hover:border-white/20 hover:text-white transition-all duration-200 select-none"
                  >
                    {skill}
                  </span>
                ))}
              </div>

              {/* Right Stage: Completion Date & Direct Link */}
              <div className="flex items-center justify-between md:justify-end gap-6 shrink-0 font-mono text-xs text-zinc-400 md:w-1/4">
                <span>{item.issueDate}</span>
                {item.credentialUrl && (
                  <a
                    href={item.credentialUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border border-white/[0.08] hover:border-[#af5bf0]/40 bg-white/[0.02] hover:bg-white/[0.05] text-zinc-300 group-hover:text-white transition-all duration-200 cursor-pointer group/verify"
                  >
                    <span className="text-xs uppercase tracking-wider hidden sm:inline">Verify Credential</span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-zinc-400 group-hover/verify:text-[#af5bf0] group-hover/verify:translate-x-0.5 group-hover/verify:-translate-y-0.5 transition-all shrink-0" />
                  </a>
                )}
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}


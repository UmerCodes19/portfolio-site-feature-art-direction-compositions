import { Hero } from "@/components/Hero";
import { ProjectsSection } from "@/components/projects/ProjectsSection";
import { ExperienceSection } from "@/components/experience/ExperienceSection";
import { EducationSection } from "@/components/education/EducationSection";
import { CredentialsSection } from "@/components/credentials/CredentialsSection";
import { ContactSection } from "@/components/contact/ContactSection";

export default function Home() {
  return (
    <main className="bg-[#080808] min-h-screen text-white selection:bg-white selection:text-black">
      <Hero />
      <ProjectsSection />
      <ExperienceSection />
      <EducationSection />
      <CredentialsSection />
      <ContactSection />
    </main>
  );
}






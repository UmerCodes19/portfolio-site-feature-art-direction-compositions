"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import { Project } from "@/data/projects";

interface FeaturedProjectCardProps {
  project: Project;
  onSelect: (project: Project) => void;
  variant: "full" | "half";
}

export function FeaturedProjectCard({
  project,
  onSelect,
  variant,
}: FeaturedProjectCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);
  const imageRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const isGif = project.coverImage.endsWith(".gif");

  useEffect(() => {
    if (typeof window === "undefined") return;
    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    setPrefersReducedMotion(mediaQuery.matches);

    const handleChange = (e: MediaQueryListEvent) =>
      setPrefersReducedMotion(e.matches);
    mediaQuery.addEventListener("change", handleChange);
    return () => mediaQuery.removeEventListener("change", handleChange);
  }, []);

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => onSelect(project)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onFocus={() => setIsHovered(true)}
      onBlur={() => setIsHovered(false)}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onSelect(project);
        }
      }}
      className="featured-card-item group cursor-pointer outline-none focus-visible:ring-1 focus-visible:ring-white/20 focus-visible:ring-offset-2 focus-visible:ring-offset-[#080808]"
    >
      {/* Image Window Container — top-to-bottom clip-path mask wipe target */}
      <div
        ref={imageRef}
        className="featured-image-wrap relative w-full overflow-hidden rounded-2xl bg-zinc-950/90 border border-white/[0.08] group-hover:border-white/[0.22] shadow-[0_8px_30px_rgb(0,0,0,0.4)] transition-all duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] opacity-0"
        style={{ clipPath: "inset(0% 0% 100% 0%)" }}
      >
        <div className="relative w-full aspect-[16/10] overflow-hidden">
          {/* Inner image is translated vertically inside overflow-hidden window for scrubbed parallax */}
          <div className="featured-image-inner absolute -inset-y-12 inset-x-0 w-full h-[calc(100%+6rem)] will-change-transform">
            <Image
              src={project.coverImage}
              alt={project.title}
              fill
              priority={variant === "full"}
              unoptimized={isGif}
              sizes={
                variant === "full"
                  ? "(max-width: 768px) 100vw, 1280px"
                  : "(max-width: 768px) 100vw, 640px"
              }
              style={{
                animationPlayState:
                  isGif && !prefersReducedMotion && !isHovered
                    ? "paused"
                    : "running",
              }}
              className="object-cover brightness-[0.92] contrast-[1.06] grayscale-[0.15] group-hover:grayscale-0 group-hover:brightness-100 group-hover:scale-[1.02] transition-all duration-700 ease-[cubic-bezier(0.16,1,0.3,1)]"
            />
            {/* Subtle optical vignette gradient */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-black/10 opacity-60 group-hover:opacity-20 transition-opacity duration-700 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Typography Block — split-stagger target & subtle parallax lag */}
      <div
        ref={textRef}
        className="featured-text-block pt-6 sm:pt-8 flex flex-col gap-2.5 opacity-0 transform translate-y-6"
      >
        <div className="flex items-baseline justify-between gap-4">
          <div className="flex items-baseline gap-3.5">
            <span className="font-mono text-xs tracking-[0.2em] text-zinc-500 select-none tabular-nums shrink-0 font-medium">
              {project.index}
            </span>
            <h3
              className={`font-light tracking-[-0.035em] text-zinc-100 group-hover:text-white transition-colors duration-300 ${
                variant === "full"
                  ? "text-3xl sm:text-4xl md:text-5xl leading-[1.06]"
                  : "text-2xl sm:text-3xl leading-[1.1]"
              }`}
            >
              {project.title}
            </h3>
          </div>
          <span className="hidden sm:inline-block font-mono text-[11px] tracking-[0.15em] text-zinc-500 group-hover:text-zinc-400 transition-colors uppercase">
            {project.category}
          </span>
        </div>
        <p
          className={`font-light leading-[1.65] text-zinc-400/90 group-hover:text-zinc-300 transition-colors duration-300 ${
            variant === "full"
              ? "text-base sm:text-lg max-w-[62ch]"
              : "text-sm sm:text-base max-w-[48ch]"
          }`}
        >
          {project.tagline}
        </p>
        <div className="flex items-center gap-2 pt-1 flex-wrap">
          {project.tags.slice(0, 4).map((tag) => (
            <span
              key={tag}
              className="featured-tag inline-block text-[10px] font-mono tracking-[0.14em] uppercase text-zinc-400 bg-white/[0.03] border border-white/[0.06] group-hover:border-white/[0.12] px-2.5 py-1 rounded-md transition-all duration-300 opacity-0 transform translate-y-2"
            >
              {tag}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
